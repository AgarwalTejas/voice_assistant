# Centralized error handling logic
def handle_error(error):
    print(f"[ERROR]: {str(error)}")
