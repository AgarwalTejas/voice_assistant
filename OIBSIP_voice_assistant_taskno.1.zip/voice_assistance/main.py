# Entry point for the voice assistant
from speech_recognition_module import recognize_speech
from nlp_module import process_command
from task_automation import execute_task
from error_handling import handle_error

def main():
    print("Voice Assistant Activated. Say 'exit' to quit.")
    while True:
        try:
            command = recognize_speech()
            if command.lower() == "exit":
                print("Goodbye!")
                break
            if command:
                intent = process_command(command)
                execute_task(intent)
        except Exception as e:
            handle_error(e)

if __name__ == "__main__":
    main()
