# API keys and configuration settings
# Add API keys here if needed
OPENWEATHER_API_KEY = "your_openweather_api_key"
