# Natural Language Processing logic using libraries like spaCy or transformers
def process_command(text):
    text = text.lower()
    if "email" in text:
        return {"action": "send_email", "details": text}
    elif "reminder" in text:
        return {"action": "set_reminder", "details": text}
    elif "weather" in text:
        return {"action": "get_weather", "details": text}
    elif "light" in text or "fan" in text:
        return {"action": "control_device", "details": text}
    elif "who is" in text or "what is" in text:
        return {"action": "general_knowledge", "details": text}
    else:
        return {"action": "unknown", "details": text}
