# Code to automate tasks like sending emails, fetching weather, controlling devices
import webbrowser

def execute_task(intent):
    action = intent["action"]
    if action == "send_email":
        print("Sending email... (Mock)")
    elif action == "set_reminder":
        print("Reminder set!")
    elif action == "get_weather":
        print("It's 30°C and sunny today.")  # Later, integrate OpenWeatherMap API
    elif action == "control_device":
        print("Smart device toggled.")
    elif action == "general_knowledge":
        query = intent["details"]
        webbrowser.open(f"https://www.google.com/search?q={query}")
    else:
        print("Command not recognized.")
